self.assetsManifest = {
  "version": "6R5HpoGG",
  "assets": [
    {
      "hash": "sha256-kVuaMSf5OjaMZiCWiMP6uAqloB+4LH7aOdMdHg5TMZc=",
      "url": "_content/RclShared/appsettings.json"
    },
    {
      "hash": "sha256-WeOKCkI7IdJHs2kCqsKgLfiWX4/sNPbaRUspOLefkCY=",
      "url": "_content/RclShared/background.png"
    },
    {
      "hash": "sha256-2rGCF/hMx+1cxJRGuQ0ioOj5URSKaL7HysVFfJiXQWI=",
      "url": "_content/RclShared/css/app.css"
    },
    {
      "hash": "sha256-T/BhnMl6TojQCgx2Aj24AnfxS9vNkTQsJlztjKuHpao=",
      "url": "_framework/LocalizationCatalog.pui98ggcsa.wasm"
    },
    {
      "hash": "sha256-u6020V5iQH94W0eBD2TjY5Kx70hrT7Z6PKWA/vVoSZc=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.7lgr5z9odp.wasm"
    },
    {
      "hash": "sha256-5gwmCzjwDw68WQnjH+pxeqwFxPIbs4HwhWLHTsRmYxc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.yuohbolrnc.wasm"
    },
    {
      "hash": "sha256-f3TUGad0KOmWJz1h9hH+wucHK238YVtiC38KJfmpgDk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xk59f6g7k3.wasm"
    },
    {
      "hash": "sha256-wD2An8xBkv/QNhzyUePweXrYMk+caBE13RS5A1QEWCA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.8ahvdbuxhr.wasm"
    },
    {
      "hash": "sha256-VpOI0PpJZWE56Je2jdSuWrHfza3nBC8exvTZQrj6e2Q=",
      "url": "_framework/Microsoft.AspNetCore.Components.uy7c8avemq.wasm"
    },
    {
      "hash": "sha256-RTC7aDokDmNlsGo2yVFEev964XVR63yW5fGx1GWiuT4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.hh5e5ah6dl.wasm"
    },
    {
      "hash": "sha256-Cqlhoe01mLV4U3zPHqakcUOKb+tS5xROlex4joWV0MI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.y2evsd2x7q.wasm"
    },
    {
      "hash": "sha256-O//lmM7iBWUtBjH2FJ3NMhOI8xRMCAko/BmV8+lm5Do=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.frazqtnewj.wasm"
    },
    {
      "hash": "sha256-fZV+zqLP7o/3FS7O68fHgymua3Wiee3vJh7ehLIvC0w=",
      "url": "_framework/Microsoft.Extensions.Configuration.r2e9z2b7rs.wasm"
    },
    {
      "hash": "sha256-nhMsFWDy/OlCEUKGoNXpi13v8KyYIVu9rReQVckajEc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.uwcdxca2aa.wasm"
    },
    {
      "hash": "sha256-BoC4IaIn4gTK5fp6lkWpNObM7wNMfTYpbARl7nl0wyY=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.mt5uv2cyps.wasm"
    },
    {
      "hash": "sha256-v+otsOru6WbL+CHP/3cPo4JgAAj3STmMLgF/rk3H8Sg=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.18uxinjvcd.wasm"
    },
    {
      "hash": "sha256-8wSDsBxkv8dawNC4a8QjG8C7kVtNPif+Tw0wL42h5fw=",
      "url": "_framework/Microsoft.Extensions.Localization.jwe6ovkd3t.wasm"
    },
    {
      "hash": "sha256-iVOv34nFs4bS12nIrNoOGVvD2vMhnwe4Vjyg+qYxxeM=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.bracjesh05.wasm"
    },
    {
      "hash": "sha256-mxF+Guk2KJWi6cbiTn01RUGWJGOPYqL+HD8od8itqQs=",
      "url": "_framework/Microsoft.Extensions.Logging.t2oe1fovjy.wasm"
    },
    {
      "hash": "sha256-GL5Y4LEqPZVCX/i8dmFqT+KutO9VrTsYa1Rc9XJqCb4=",
      "url": "_framework/Microsoft.Extensions.Options.s782sr4c30.wasm"
    },
    {
      "hash": "sha256-wYd6P1RQVdx1wLGbVUXdca6pRBBwPJthqnLyxO6UMf0=",
      "url": "_framework/Microsoft.Extensions.Primitives.1w0lc1mcj1.wasm"
    },
    {
      "hash": "sha256-q66DgMDVe0j5t5W6CBWuOybJfxVf1p7oarfQQ5bXyH0=",
      "url": "_framework/Microsoft.Extensions.Validation.lspj8863f6.wasm"
    },
    {
      "hash": "sha256-9MrMSaF3Ux7qJdu19tfa59lYtIOsndS8NEbyw4VNnOA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.gfego8d62w.wasm"
    },
    {
      "hash": "sha256-rhkZzDp2ebvAxhDnek0nsJjoMSwpdpTjPKBU+lMAPpI=",
      "url": "_framework/Microsoft.JSInterop.amf1lvlq73.wasm"
    },
    {
      "hash": "sha256-wM8k9xhmMVvCIm6CZBUTjz0Wgyh8a49WPfowvwETgwM=",
      "url": "_framework/NetAi.LetterLoom.Web.w8gcnbd4nv.wasm"
    },
    {
      "hash": "sha256-AqzRcwvkwDpoIC5viZ6YtWNX7t7BdDTXxUEdNEB3R6M=",
      "url": "_framework/RclShared.2ws3bn971h.wasm"
    },
    {
      "hash": "sha256-/idD2jXyeeMNGS4WlK8QjT5JOeMyFJIj4AOTdQSk0ko=",
      "url": "_framework/System.Collections.Concurrent.apbr8fd9na.wasm"
    },
    {
      "hash": "sha256-iKJxQqs4KwFOJJm8aho8E1j/yIW6/vzQOFisJx1WHgc=",
      "url": "_framework/System.Collections.Immutable.ga57w73zif.wasm"
    },
    {
      "hash": "sha256-ZuMnNNw7MtM6/pRRWgLT+gS6zR48v4uOz3Jp/xQ8wAs=",
      "url": "_framework/System.Collections.NonGeneric.moj7ovhy1z.wasm"
    },
    {
      "hash": "sha256-OEDm/uZ5G5Zb4KTcueTzZbixSHr/pX2L4gsYlf7p4zA=",
      "url": "_framework/System.Collections.Specialized.w6oj7a7wxu.wasm"
    },
    {
      "hash": "sha256-RsKVLMQgfmHwMoGc1uYAFLpqFJItAQHibT8+jdsMhoY=",
      "url": "_framework/System.Collections.en3prxofms.wasm"
    },
    {
      "hash": "sha256-81rBiyWJDM5jq8LM5PCClLgDXBEdgJEKHj0lGHL7pPw=",
      "url": "_framework/System.ComponentModel.Annotations.v52o69ff7i.wasm"
    },
    {
      "hash": "sha256-fzk7dPBlN+zw9vxH2O9zyalCXh4K7EeXeqRGJHfkZgs=",
      "url": "_framework/System.ComponentModel.Primitives.9ibpkbet1r.wasm"
    },
    {
      "hash": "sha256-vIUDU0hpDIAYMiPqDXrvh6fQp48fxbdOSSLbUXAXAVc=",
      "url": "_framework/System.ComponentModel.TypeConverter.sosa64sj30.wasm"
    },
    {
      "hash": "sha256-1DK+7RVVxjyacfg+DeNoPPQTLvx1/Pns3EGltfpnprk=",
      "url": "_framework/System.ComponentModel.csjo7z4dry.wasm"
    },
    {
      "hash": "sha256-tNSVmQ4EWWNrsR0XJCp47rGdTGAfy2iHodrjNgeDMdI=",
      "url": "_framework/System.Console.w95crtqw1p.wasm"
    },
    {
      "hash": "sha256-KgV+DbjLbPwN/UJ7DTLqKuT5VC3xf+g+vzoals6GWf8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.a84vy7kbwz.wasm"
    },
    {
      "hash": "sha256-cqErL/uySqxhOv+qMIKxJRN+BNOZGiDCnPyg1+ZIZRc=",
      "url": "_framework/System.IO.Pipelines.icfrnhwz5f.wasm"
    },
    {
      "hash": "sha256-xohvnd/oRnCIf1hbXxMQuH0SEewJyxIuTANnFWbqR4Q=",
      "url": "_framework/System.Linq.Expressions.iere9zql0y.wasm"
    },
    {
      "hash": "sha256-PKZlcE2OhLuVFa38ixdk+gPLmGYTEcXw6FsJu4fQQOM=",
      "url": "_framework/System.Linq.cy3jvsp3pz.wasm"
    },
    {
      "hash": "sha256-bcxfZ5/HbQ7R7fMUFYJabTOQvaQ6mTjiiGjrduvd1Kw=",
      "url": "_framework/System.Memory.fh2s0mu5zx.wasm"
    },
    {
      "hash": "sha256-NyxhJEYXrhw77w0elq0kmqgwpp/nZr6Q03+k122Za6I=",
      "url": "_framework/System.Net.Http.746hregke8.wasm"
    },
    {
      "hash": "sha256-epE4eGHnGEfxKoGLlQexmvpOfOD4c8XBWqyt2YfvBWk=",
      "url": "_framework/System.Net.Http.Json.ylngby2fcm.wasm"
    },
    {
      "hash": "sha256-s9rRUomPsrQ7CPYjy7VfHuyk+5Zcz4sL/Uy1Bx9uYZg=",
      "url": "_framework/System.Net.Primitives.be7t0gdwz9.wasm"
    },
    {
      "hash": "sha256-oDIra1QUOaw1Uzbky0Lon++bc1OtQlDn795mBakoHMk=",
      "url": "_framework/System.ObjectModel.kffauu7p2x.wasm"
    },
    {
      "hash": "sha256-COOr2kBEMSSAoeD9ZrRqBg6CN6a0EBNXxRkKK5QN9rM=",
      "url": "_framework/System.Private.CoreLib.giav2p1ytk.wasm"
    },
    {
      "hash": "sha256-2ez+3th4pERSEUHq6s0HKx61uZfhR3rehNmrf3GCraI=",
      "url": "_framework/System.Private.Uri.ps1zdntxps.wasm"
    },
    {
      "hash": "sha256-hj26LVfbFpoVPyXTjAXdVk41FKNiFwr2eGNynxIaSNQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.qba5uzr262.wasm"
    },
    {
      "hash": "sha256-hxuNmbus2Z+63XM9Eth9ODyEKJMMiyGzEU4DEKpipEw=",
      "url": "_framework/System.Runtime.Serialization.Primitives.1u4wc6yayu.wasm"
    },
    {
      "hash": "sha256-Z9GrXGahI3L+xSf48bGzhO3po39NJRQvZxbSb41H1tQ=",
      "url": "_framework/System.Runtime.haepy2vie9.wasm"
    },
    {
      "hash": "sha256-sJvdG9iEW9S28wAoeZPsjuZ+Dn5lEaiWXp+3JNDZgcw=",
      "url": "_framework/System.Security.Cryptography.knctfgxfsk.wasm"
    },
    {
      "hash": "sha256-hznDrpfpssXUZvG0M4Jm2zR3d5qC3tBjcvJiVMKkKns=",
      "url": "_framework/System.Text.Encodings.Web.tzfi5wo6cs.wasm"
    },
    {
      "hash": "sha256-O8RklsU1DCUuYTGkm5opM0iUjc8KY4qfEErRdWlWhRg=",
      "url": "_framework/System.Text.Json.v7ys0mt5y2.wasm"
    },
    {
      "hash": "sha256-BJoYlgx4zWr/Ut7R2HdSbR/o+HMgBRhmUlMWFeaiSpE=",
      "url": "_framework/System.Text.RegularExpressions.0rrilxv7qg.wasm"
    },
    {
      "hash": "sha256-Gs5bAip0Y07Y7rdk4CYnpzrBeGplAudFAELUELfBy80=",
      "url": "_framework/System.a3z5tpzyvn.wasm"
    },
    {
      "hash": "sha256-/Iz7qZ9NvL7Gqpx7VR4gGGE+Yxcy1XKBmkZg/pCQuTg=",
      "url": "_framework/ar/RclShared.resources.0t3ns9ym9h.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-gmbvB/3aoeeoKZjnpXlfsGlE2UmgmQ6+fdev8v/hgSQ=",
      "url": "_framework/dotnet.myiy5s3nl5.js"
    },
    {
      "hash": "sha256-YlIWUrqwAiQuAJNBOX+Zm9wpWL+sF3J449iFq7JHouQ=",
      "url": "_framework/dotnet.native.a6k1euv12n.wasm"
    },
    {
      "hash": "sha256-CZ0IVZkLTIvee7n1yVvOitlJWNdj/YjaFgpMgliIM64=",
      "url": "_framework/dotnet.native.bjoj0wmylw.js"
    },
    {
      "hash": "sha256-/3dBg9sj1yLD3h0PDMHnNUXWs/2zWwIMEzom1Xz3Q40=",
      "url": "_framework/dotnet.runtime.5nc8i5dl74.js"
    },
    {
      "hash": "sha256-AdJY3IpHXzA04WInXLV7hOO0x/+iCQkFtWMqQbX2eHA=",
      "url": "_framework/en/RclShared.resources.t96hcjuoxl.wasm"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-Y0naPDhGgMtU4sCxFv1tF+gmgiSfbPbXkV/aCWto+UA=",
      "url": "_framework/ru/RclShared.resources.7jfbu67w0g.wasm"
    },
    {
      "hash": "sha256-CMk2EZTxVJMPia+7E3NdgsBCE7w2+a/W090MsEHcFJY=",
      "url": "_framework/zh-hant/RclShared.resources.owzd6bclij.wasm"
    },
    {
      "hash": "sha256-+2rjU6/WlwJ/waOnWkuVo+h4vJ+YePWIgdSynPImuQA=",
      "url": "_headers"
    },
    {
      "hash": "sha256-vtUY/M8IJy8xxcW/uMqeyn9Kod5OkGVmxTQLSetUCdk=",
      "url": "_redirects"
    },
    {
      "hash": "sha256-tAX4NUUmKQNRjm31LEcYq9L6MwqU7Ct9Ajb1Bwghewg=",
      "url": "css/app-web.css"
    },
    {
      "hash": "sha256-ltilJ/YZ4iUsXWYuP3L4nGzcwbwIKo3MOSsWgw+iaRQ=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-tiVfbE8E7x8kCYOIsXZ9iSmeOLBpM5r8+ITs6qT3jyM=",
      "url": "downloads/LetterLoom-Portable-1.0.0.exe"
    },
    {
      "hash": "sha256-Rbtc1tiWqmca0mcNFUbLw4uq+4CaFIED5JzdnpHHteY=",
      "url": "downloads/LetterLoom-Setup-1.0.0.exe"
    },
    {
      "hash": "sha256-oBhvjFBbNqEvxsqEDdqptuNXC/OLNC0VvpJX693ekq4=",
      "url": "downloads/downloads.json"
    },
    {
      "hash": "sha256-ThoIeoQhybXxCXHnz0QnGYDod+vxIB/x0i6Zy3jIosM=",
      "url": "downloads/version.json"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-X0yPSUM9aVh8v3cTNRJO1JpnvIm6zYKmEMii0VA5e+g=",
      "url": "img/hero-letter.webp"
    },
    {
      "hash": "sha256-AIDw1BnJyh1g2oIbpDAlyGEYRCeDfFMJELtUZmGG/co=",
      "url": "index.html"
    },
    {
      "hash": "sha256-jDDUCYDGfGO08ai3GBFyxz0XnGSoIKiU/sGk/jpWxn0=",
      "url": "js/web-interop.js"
    },
    {
      "hash": "sha256-UiDpTVUHIheNGpTKaTwm7c68F43Y7R5k4lRK5nFiRYg=",
      "url": "manifest.webmanifest"
    }
  ]
};
